//
//  NPClickThroughController.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2012-08-22.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef BOOL (^JMClickThroughPredicateBlock)(NSWindow *window, NSPoint locationInWindow);

@protocol NPClickThroughProtocol;

// Windows that want to ignore mouse events in programmable locations must register themselves
// in the NPClickThroughController singleton.
//
// Note that the standard -ignoresMouseEvents/setIgnoresMouseEvents: API is unavailable while
// a window is registered into NPClickThroughController.
@interface NPClickThroughController : NSObject
+ (NPClickThroughController *)controller;

// Start updating window's ignoresMouseEvents based on current mouse position.
// PredicateBlock is called on every mouse move; ignoresMouseEvents is set to its result.
// Does not retain window.
- (void)registerWindow:(NSWindow *)window predicateBlock:(JMClickThroughPredicateBlock)predicateBlock;

// Shortcut for the above when the window implements -ignoresMouseEventsAtLocation: directly.
- (void)registerWindow:(NSWindow<NPClickThroughProtocol> *)window;

// Stop updating window's ignoresMouseEvents based on current mouse position.
// This must be called before the window is deallocated.
- (void)deregisterWindow:(NSWindow *)window;

// Refreshes click-through state at the end of this runloop iteration without waiting
// for a mouse move event.
// Useful when you reconfigure what -ignoresMouseEventsAtLocation: returns and you want
// the new result to apply on clicks that arrive before the next mouse move.
- (void)refresh;
@end

@protocol NPClickThroughProtocol <NSObject>
// Indicates whether the window is to be transparent to mouse events at a specific location in window coordinates.
// This lets you turn click-through on in any area of your window, including semitransparent
// or opaque areas (such as transparent layer-backed views that look like opaque OpenGL contexts to the window server).
- (BOOL)ignoresMouseEventsAtLocation:(NSPoint)locationInWindow;
@end

