//
//  NPMenu.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-04-24.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <NinePatch/NPStyleable.h>

typedef NS_ENUM(int, NPMenuArrowAnchor) {
    NPMenuArrowAnchorLeft,
    NPMenuArrowAnchorCenter,
    NPMenuArrowAnchorRight
};

@interface NPMenu : NSMenu<NPStyleable>

@property (nonatomic, readonly) CGFloat maxKeyEquivalentWidth;

// Pop up menu with an arrow centered at the top or bottom, pointing at the rect given.
// If view is nil, then rect is given in screen coordinates; otherwise view coordinates.
// The menu's position will be adjusted to keep the menu on screen, if necessary.
- (BOOL)popUpMenuWithArrowPointingAtRect:(CGRect)rect inView:(NSView *)view;

// Pop up menu with an arrow at the top or bottom, with the horizontal position described
// by offset/relativeTo.
// This can be used to adjust the horizontal position of the menu to avoid overlaps with
// nearby UI elements, if possible.
- (BOOL)popUpMenuWithArrowAtOffset:(CGFloat)offset
                        relativeTo:(NPMenuArrowAnchor)relativeTo
                    pointingAtRect:(CGRect)rect
                            inView:(NSView *)view;

@end
