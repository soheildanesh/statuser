//
//  NPNinePatch+PackageFormat.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2012-10-01.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <ninepatch/NPNinePatch.h>

// This category implements loading and saving nine part images in a transparent package format (*.9p).
// These packages are simply a directory holding the 1x and 2x PNG source images
// and a plist describing the rest of the properties.
@interface NPNinePatch (PackageFormat)
+ (NPNinePatch *)ninePatchFromPackageRepresentation:(NSFileWrapper *)fileWrapper;
- (NSFileWrapper *)packageRepresentation;
@end
