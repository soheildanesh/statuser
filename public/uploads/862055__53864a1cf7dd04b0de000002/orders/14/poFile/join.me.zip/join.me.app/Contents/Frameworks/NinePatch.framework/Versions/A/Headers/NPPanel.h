//
//  NPPanel.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2012-08-24.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPWindow.h>

// A subclass of NSPanel that draws a nine patch image as its border.
@interface NPPanel : NSPanel<NPWindowFrameDelegate>

@property (nonatomic, unsafe_unretained) id<NPWindowDelegate> delegate;

@property (nonatomic, strong) NSView *npContentView;
@property (nonatomic, readonly) NPWindowFrame *npWindowFrame;

@property (nonatomic, assign) BOOL canBeMain;
@property (nonatomic, assign) BOOL canBeKey;

- (id)initWithContentRect:(NSRect)contentRect ninePatch:(NPNinePatch *)ninePatch;
- (id)initWithContentRect:(NSRect)contentRect ninePatch:(NPNinePatch *)ninePatch styleMask:(NSUInteger)windowStyle;
@end
