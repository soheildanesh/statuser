//
//  NPStackView.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-08-05.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPView.h>

typedef enum {
    NPStackAlignmentNone, // Keep original orthogonal position (default)
    NPStackAlignmentCenter,
    NPStackAlignmentLeft,
    NPStackAlignmentRight,
    NPStackAlignmentBottom = NPStackAlignmentLeft,
    NPStackAlignmentTop = NPStackAlignmentRight,
    NPStackAlignmentStretch,
} NPStackAlignment;

// A view that positions an array of subviews below (or besides) each other.
@interface NPStackView : NPView 
@property (nonatomic, assign, getter=isHorizontal) BOOL horizontal;
@property (nonatomic, assign) NPStackAlignment alignment;
@property (nonatomic, assign) CGFloat minimumOrthogonalSize;

// Number of component views (without padding)
@property (nonatomic, readonly) NSUInteger componentCount;

+ (NPStackView *)stackView;
+ (NPStackView *)horizontalStackView;

+ (NPStackView *)stackViewWithComponentsAndAlignments:(id)firstComponent, ... NS_REQUIRES_NIL_TERMINATION;
+ (NPStackView *)horizontalStackViewWithComponentsAndAlignments:(id)firstComponent, ... NS_REQUIRES_NIL_TERMINATION;

// Add a view to the bottom (or right) end of the stack.
// Does not add view as a subview; this is done by updateLayout.
- (void)addComponentView:(NSView *)view; 
- (void)addComponentView:(NSView *)view alignment:(NPStackAlignment)alignment;

// Add the specified amount of extra space to the bottom (or right) end of the stack.
- (void)addPadding:(CGFloat)padding;

- (void)removeAllComponents;

// Positions component views and sets a new size for the StackView.
- (void)updateLayout; 

@end
