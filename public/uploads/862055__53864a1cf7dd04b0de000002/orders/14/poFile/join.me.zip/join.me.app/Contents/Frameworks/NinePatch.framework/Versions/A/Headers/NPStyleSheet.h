//
//  NPStyleSheet.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-05.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol NPStyleable;
@class NPStyle;

@interface NPStyleSheet : NSObject
+ (instancetype)styleSheet;

// NPMenuItem.main-menu:highlighted:small
// (class-name | '*') [ '.' context ] [ ':' state-name ]*
- (void)addEntryWithSelector:(NSString *)selector attributes:(NSDictionary *)attributes;

- (void)addEntryWithClass:(Class)cls context:(NSString *)context state:(NSDictionary *)state attributes:(NSDictionary *)attributes;

- (NPStyle *)styleForObject:(id<NPStyleable>)object;

@end
