//
//  NPTextFieldCell.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-09.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPNinePatch.h>

// A subclass of NSTextFieldCell that draws a nine patch image as its background.
// The text is drawn inside the image's contents area.
// 
// The class also provides support for custom field editors. 
@interface NPTextFieldCell : NSTextFieldCell 
@property (nonatomic, strong) NPNinePatch *ninePatch;
@property (nonatomic, strong) NSTextView *fieldEditor;

@end
