//
//  NPView.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-05.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <ninepatch/NPNinePatch.h>

// A view that draws a nine patch image.
//
// The NinePatchView ensures that its content view's frame matches the nine patch image's content rectangle.
// Other subviews are autosized as usual, ignoring the content rectangle.
@interface NPView : NSView
@property (nonatomic, strong) NPNinePatch *ninePatch; // Setter updates contentInsets
@property (nonatomic, strong) NSView *contentView;
@property (nonatomic, strong) NSColor *backgroundColor;
@property (nonatomic, assign) BOOL cancelsFirstResponder;
@property (nonatomic, assign) BOOL acceptsFirstMouse;

@property (nonatomic, assign) NPEdgeInsets marginInsets;
@property (nonatomic, assign) NPEdgeInsets contentInsets; // Includes margin

- (id)initWithFrame:(NSRect)frame ninePatch:(NPNinePatch *)ninePatch;

- (NSSize)sizeForContentSize:(NSSize)contentSize;
- (NSRect)frameForContentFrame:(NSRect)contentFrame;

- (NSSize)contentSizeForSize:(NSSize)size;
- (NSRect)contentFrameForFrame:(NSRect)frame;

- (NSRect)contentFrame;

- (void)setMouseDownCanMoveWindow:(BOOL)mouseDownCanMoveWindow;
@end
