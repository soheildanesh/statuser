//
//  NPWindow.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-05.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPMask.h>
#import <ninepatch/NPClickThroughController.h>
#import <ninepatch/NPWindowFrame.h>

@class NPWindow;

@protocol NPWindowDelegate <NSWindowDelegate>
@optional
- (NSSize)npWindowWillResize:(NSWindow *)window byPatch:(NPPatch)patch originalSize:(NSSize)oldSize newSize:(NSSize)newSize;
- (NSRect)npWindowWillResize:(NSWindow *)window byPatch:(NPPatch)patch originalFrame:(NSRect)oldFrame newFrame:(NSRect)newFrame;
- (NSRect)npWindowWillZoom:(NSWindow *)window toVisualFrame:(NSRect)defaultFrame; // Visual frames.
@end

// A subclass of NSWindow that draws a nine patch image as its border.
@interface NPWindow : NSWindow<NPWindowFrameDelegate>

@property (nonatomic, unsafe_unretained) id<NPWindowDelegate> delegate;

@property (nonatomic, strong) NSView *npContentView;
@property (nonatomic, readonly) NPWindowFrame *npWindowFrame;

@property (nonatomic, assign) BOOL canBeMain;
@property (nonatomic, assign) BOOL canBeKey;

- (id)initWithContentRect:(NSRect)contentRect ninePatch:(NPNinePatch *)ninePatch;
- (id)initWithContentRect:(NSRect)contentRect ninePatch:(NPNinePatch *)ninePatch styleMask:(NSUInteger)windowStyle;
@end

