//
//  NSColor+NinePatch.h
//  mac_frontend
//
//  Created by Károly Lőrentey on 2013-02-06.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSColor (NinePatch)

@property (nonatomic, readonly) CGColorRef npCGColor;

- (void)npSetStrokeColorForContext:(CGContextRef)c;
- (void)npSetFillColorForContext:(CGContextRef)c;

+ (NSColor *)colorWithHexValue:(uint32)hexValue;

+ (NSColor *)npRandomSaturatedColorWithAlpha:(CGFloat)alpha;

@end
