//
//  NSValue+NinePatch.h
//  ninepatch
//
//  Created by Karoly Lorentey on 5/13/13.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSValue (NinePatch)

+ (instancetype)valueWithInsets:(NPEdgeInsets)insets;
+ (instancetype)insetsWithTop:(CGFloat)top left:(CGFloat)left bottom:(CGFloat)bottom right:(CGFloat)right;

- (NPEdgeInsets)insetsValue;

@end
