//
//  NSView+NinePatch.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-02-17.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSView (NinePatch)

// Returns the intrinsic contents scale, i.e., the scale of the parent window (or the main screen).
@property (nonatomic, readonly) CGFloat npBackingScaleFactor;

- (CGRect)npConvertRectToScreen:(CGRect)rect;
- (CGRect)npConvertRectFromScreen:(CGRect)rect;
- (CGPoint)npConvertPointToScreen:(CGPoint)point;
- (CGPoint)npConvertPointFromScreen:(CGPoint)point;

@end
