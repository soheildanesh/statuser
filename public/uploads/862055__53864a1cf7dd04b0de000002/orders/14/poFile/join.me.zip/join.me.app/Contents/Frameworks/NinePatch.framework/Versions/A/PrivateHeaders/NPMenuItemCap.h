//
//  NPMenuItemCap.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-15.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <NinePatch/NPMenu.h>

@interface NPMenuItemCap : NSMenuItem

@property (nonatomic, assign) BOOL topCap;

@property (nonatomic, assign) CGRect arrowDestinationRect; // in screen coordinates

- (id)init;
- (void)drawRect:(NSRect)dirtyRect inView:(NSView *)view;

@end
