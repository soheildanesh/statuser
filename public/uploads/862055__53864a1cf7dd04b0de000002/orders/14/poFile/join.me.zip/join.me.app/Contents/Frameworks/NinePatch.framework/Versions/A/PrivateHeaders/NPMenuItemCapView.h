//
//  NPMenuItemCapView.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-15.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class NPMenuItemCap;

@interface NPMenuItemCapView : NSView

@property (nonatomic, unsafe_unretained) NPMenuItemCap *menuItem;

- (id)initWithHeight:(CGFloat)height menuItem:(NPMenuItemCap *)menuItem;

@end
