//
//  NPMenuItem_Private.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-04-26.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <NinePatch/NinePatch.h>

@class NPMenuItemView;

@interface NPMenuItem ()
@property (nonatomic, retain) NPMenuItemView *npView;
- (void)npMouseDown:(NSEvent *)event;
- (void)npMouseDragged:(NSEvent *)event;
- (void)npMouseUp:(NSEvent *)event;

- (void)npPerformAction;
@end
