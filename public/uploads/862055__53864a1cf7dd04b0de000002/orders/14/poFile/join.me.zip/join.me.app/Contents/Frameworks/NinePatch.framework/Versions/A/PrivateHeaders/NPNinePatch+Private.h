//
//  NPNinePatch+Private.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2012-10-01.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <ninepatch/NPNinePatch.h>

@interface NPNinePatch ()
@property (nonatomic, readonly) NSData *pngData1x;
@property (nonatomic, readonly) NSData *pngData2x;

- (id)initWithPNGData1x:(NSData *)data1x
              PNGData2x:(NSData *)data2x
           centerInsets:(NPEdgeInsets)centerInsets
          contentInsets:(NPEdgeInsets)contentInsets
             maskInsets:(NPEdgeInsets)maskInsets
   tileCenterVertically:(BOOL)tileCenterVertically
 tileCenterHorizontally:(BOOL)tileCenterHorizontally;

- (NSData *)PNGDataFromCGImage:(CGImageRef)cgimage;

@end
