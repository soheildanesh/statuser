//
//  NPStyleSheetEntry.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-05.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NPStyleSheet;
@class NPStyleStateValue;
@interface NPStyleSheetEntry : NSObject<NSCopying>

+ (instancetype)entryWithClass:(Class)cls context:(NSString *)context state:(NPStyleStateValue *)state attributes:(NSDictionary *)attributes;

@property (nonatomic, unsafe_unretained, readonly) NPStyleSheet *styleSheet;
@property (nonatomic, strong, readonly) Class styleClass;
@property (nonatomic, strong, readonly) NSString *context;
@property (nonatomic, strong, readonly) NPStyleStateValue *state;

@property (nonatomic, strong, readonly) NSDictionary *attributes; // attribute -> value

- (id<NSCopying>)valueForAttribute:(NSString *)attribute;

- (BOOL)isStateMatching:(NPStyleStateValue *)state;

@end
